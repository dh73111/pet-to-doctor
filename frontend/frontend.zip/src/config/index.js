const API_BASE_URL = "https://i6b209.p.ssafy.io:8443/api";

export { API_BASE_URL };
