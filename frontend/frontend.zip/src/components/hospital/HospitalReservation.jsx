import React from "react";
function HospitalReservation(props) {
    return <div></div>;
}

export default HospitalReservation;
