import React from "react";

function HosiptalReservationConfirm(props) {
    return <div></div>;
}

export default HosiptalReservationConfirm;
