import React from "react";

function UserPayment(props) {
    return <div></div>;
}

export default UserPayment;
