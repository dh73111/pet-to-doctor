import React from "react";
function Notice(props) {
    return (
        <div>
            <h1>Notice</h1>
        </div>
    );
}

export default Notice;
